# Compiling from sources ...

## Node.js
https://github.com/joyent/node/wiki/Installation